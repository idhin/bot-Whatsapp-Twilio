config = {
    apiKey: "AIzaSyCryS5-COThsKYENHlWyI8JHdJEiYHVmR0",
    authDomain: "firli-4e255.firebaseapp.com",
    databaseURL: "https://firli-4e255-default-rtdb.firebaseio.com",
    projectId: "firli-4e255",
    storageBucket: "firli-4e255.appspot.com",
    messagingSenderId: "418248248314",
    appId: "1:418248248314:web:45cc640678adb43693f243",
    measurementId: "G-TBVEHDD6M4"
}
